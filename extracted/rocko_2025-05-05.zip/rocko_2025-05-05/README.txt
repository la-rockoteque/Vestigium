================================
Obsidian Portal Campaign Backups
================================

Your campaign data is stored in the .xml file in this directory. To view it, open that file in a browser. We recommend Firefox, but any modern browser should be capable of displaying it correctly.

Special thanks to Kyle Schouviller (http://www.kyleschouviller.com) for styling it to look nice!